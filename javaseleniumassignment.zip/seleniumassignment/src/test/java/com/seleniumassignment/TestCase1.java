package com.seleniumassignment;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class TestCase1 {
	
	WebDriver driver;
	WebDriverWait wait;
	
	//opening entrata website
	@BeforeClass
	void openWebsite()
	{
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.entrata.com/");
		driver.manage().window().maximize();
		
        WebElement closeCookiesButton = driver.findElement(By.xpath("//div[@class='text-block-40']"));
        closeCookiesButton.click();
		
	}
	
	//verifying entrata website title
	@Test
	void verifyTitle()
	{
		String ActualTitle = driver.getTitle();
		String ExpectedTitle = "Property Management Software | Entrata";
		Assert.assertEquals(ExpectedTitle, ActualTitle);
		System.out.println("Title is verified");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	
	//verifying entrata website logo
	@Test
	 void verifyLogo() 
	 {
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
 
		 boolean status = driver.findElement(By.xpath("//img[@src='https://cdn.prod.website-files.com/66b25cad9398f590ab703ccf/66b25cad9398f590ab703cfc_logo.svg']")).isDisplayed();
		 System.out.println("Logo is displayed "+status);
	 }
	
	//clicking on watch demo button
	@Test(priority=1)
	void watchDemo() 
	{ 
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		WebElement watchDemoButton = driver.findElement(By.xpath("//a[@class='red-button red w-inline-block']"));
		watchDemoButton.click();
        driver.navigate().back();
        System.out.println("demo form displayed");

		
	}
	 
	//scrolling down and clicking on career option
	@Test(priority=2)
	void verifySdetrole()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		WebElement elementToClick = driver.findElement(By.xpath("//a[normalize-space()='Careers']")); 
		
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
		elementToClick.click(); 
		
		System.out.println("Career page is display");
		
	}
	
	 //closing the website
	@AfterClass
	void closeWebsite()
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.quit();
	}
		
		
		

	

}  
